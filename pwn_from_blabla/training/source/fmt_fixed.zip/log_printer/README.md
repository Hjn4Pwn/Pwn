- Binary MUST be executed in the current folder, your result will not be considered done else.
- You MUST not change (removing or adding) any environment files.
Your target is:
- Trigger the binary to read the flag.
- Propose a way of how to use a safer format specifier to prevent it.
