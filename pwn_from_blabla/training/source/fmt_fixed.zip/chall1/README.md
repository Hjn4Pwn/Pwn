Binary MUST be executed in the current folder, your result will not be considered done else.
Your target is too trigger the binary to read the flag.