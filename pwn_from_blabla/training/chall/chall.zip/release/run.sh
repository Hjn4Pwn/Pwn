#!/bin/sh
ncat -lnvp 1337 -e /home/ctf/chall -k